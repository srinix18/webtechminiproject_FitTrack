const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const cors = require("cors");
const path = require("path");

const app = express();
const port = 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, "public"))); // Serve static files

app.use(
  cors({
    origin: "http://localhost:5500", // Match the frontend URL
    credentials: true,
  })
);

app.use(
  session({
    secret: "your-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to false for http, true for https
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  })
);

// MongoDB Connection
mongoose
  .connect("mongodb://localhost:27017/userAuth")
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
  });

// User Schema
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  email: { type: String, required: true },
  name: { type: String, required: true },
  profile: {
    height: { type: Number, default: null },
    weight: { type: Number, default: null },
    age: { type: Number, default: null },
    bodyType: { type: String, default: null },
    activityLevel: { type: String, default: null },
    dailyProgress: {
      steps: { type: Number, default: 0 , required:false },
      caloriesBurned: { type: Number, default: 0,required:false },
      waterIntake: { type: Number, default: 0,required:false },
      date: { type: Date, default: Date.now ,required:false},
    },
  },
});

const User = mongoose.model("User", userSchema);

// Routes
// Serve HTML files
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

app.get("/signup", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "signup.html"));
});

app.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "hi2.html"));
});

// Signup Endpoint
app.post("/signup", async (req, res) => {
  try {
    const { username, password, email, name } = req.body;

    // Check if user exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: "Username already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user with default profile values
    const user = new User({
      username,
      password: hashedPassword,
      email,
      name,
      profile: {
        height: null,
        weight: null,
        age: null,
        bodyType: null,
        activityLevel: null,
        dailyProgress: {
          steps: 0,
          caloriesBurned: 0,
          waterIntake: 0,
          date: new Date(),
        },
      },
    });

    await user.save();

    // Set session
    req.session.userId = user._id;

    res.status(201).json({
      message: "User created successfully",
      profile: user.profile,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Login Endpoint
app.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    // Find user
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ message: "User not found" });
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(400).json({ message: "Invalid password" });
    }

    // Set session
    req.session.userId = user._id;

    res.json({
      message: "Logged in successfully",
      profile: user.profile,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update Profile Endpoint
app.post("/update-profile", async (req, res) => {
  try {
    
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Update profile fields
    user.profile = {
      ...req.body,
    };

    await user.save();
    res.json({ message: 'Profile updated successfully', profile: user.profile });
  } catch (error) {

    res.status(500).json({ message: error.message });
  }
});

// Update Daily Progress Endpoint
app.post("/update-progress", async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Update daily progress
    user.profile.dailyProgress = {
      ...user.profile.dailyProgress,
      ...req.body,
      date: new Date(),
    };

    await user.save();
    res.json({
      message: "Progress updated successfully",
      progress: user.profile.dailyProgress,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Profile Endpoint
app.get("/profile", async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ profile: user.profile });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Logout Endpoint
app.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: "Could not log out" });
    }
    res.json({ message: "Logged out successfully" });
  });
});

// Start Server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

app.get("/user-data", async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({
      id: user._id,
      username: user.username,
      email: user.email,
      name: user.name,
      profile: user.profile
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});